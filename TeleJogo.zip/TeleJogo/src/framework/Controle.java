package framework;

public class Controle {

}
